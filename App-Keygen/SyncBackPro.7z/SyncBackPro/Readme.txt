1.) Install
2.) Make sure you'll disable access to 2brightsparks.com:
　  - manually edit hosts file and add: 127.0.0.1 2brightsparks.com
3.) Use SyncBackPro keygen when asked for registration details
4.) Done.

NOTE: Never apply any updates and never let program to connect to

1.） 安装
2.） 确保禁用对 2brightsparks.com 的访问：
　　 - 手动编辑 hosts 文件并添加：127.0.0.1 2brightsparks.com
3.） 当被要求提供注册详细信息时，使用 SyncBackPro 注册机
4.）完成。

注意：切勿应用任何更新，也切勿让程序连接到

注册码：SBPR8FL001-B86A-5197-C937-8D18-4E30
